import UIKit

struct MyArray<T>{
    
    // 제네릭을 담은 빈 배열
    var elements : [T] = [T]()
    
    // 생성자
    init(_ elements: [T]){
        self.elements = elements
        
    }
}


struct Friend{
    var name: String
}

struct PpakCder {
    var name: String
}

var mySomeArray = MyArray([1,2,3])
print("mySomeArray : \(mySomeArray)")

var myStringArray = MyArray(["가", "나", "다"])
print("myStringArray : \(myStringArray)")

let friend_01 = Friend(name: "준호")
let friend_02 = Friend(name: "진혁")
let friend_03 = Friend(name: "건수")

var myFriendsArray = MyArray([friend_01, friend_02, friend_03])
print("myStringArray : \(myFriendsArray)")

// 제네릭 - <> -어떠한 자료형이던지 받을 수 있다.
