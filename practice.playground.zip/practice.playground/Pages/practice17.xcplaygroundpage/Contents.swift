import UIKit

class Friend {
    var name : String
    func changeName(newName : String){
        self.name = "하하하하! " + self.name
    }
    init(_ name : String){
        self.name = name
    }
}


var myFriend = Friend("이창형")

myFriend.changeName(newName: "개발하는 이창형")

myFriend.name

struct BestFriend {
    
    var name : String
    
    mutating func changeName(newName : String){
        self.name = newName
        print("newName: ", newName)
    }
}

var myBestFriend = BestFriend(name: "이창형")

myBestFriend.changeName(newName: "아아아!")

// struct안에서 멤버변수를 변경하고싶을때는 struct앞에 mutating을 적어주면된다.
