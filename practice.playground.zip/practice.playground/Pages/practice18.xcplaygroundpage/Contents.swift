import UIKit

//set은 중복불가 !! 고유함

var myNumberSet : Set<Int> = Set<Int>()

myNumberSet.insert(1)
myNumberSet.insert(2)
myNumberSet.insert(2)
myNumberSet.insert(3)
myNumberSet.insert(3)

//똑같은 것은 들어가지 않기 때문에 3개로 count된다.
myNumberSet.count
//set은 배열처럼 순서 고정x , 매번 바뀜
myNumberSet

for aNumber in myNumberSet{
    print("aNumber: ", aNumber)
}

var myFriends : Set<String> = ["철수", "영희", "윤정"]
var myBestFriends : [String] = ["철수", "영희", "수지"]


//contains는 안의 값이 있는지 확인해주는 것.
//있으면 true, 없으면 false
myFriends.contains("철수")
myBestFriends.contains("수지")

//없으면 nil 주고 있으면 인덱스 위치 제공
if let indexToRemove = myFriends.firstIndex(of:"윤정"){
    print("indexToRemove ",indexToRemove)
    //윤정 삭제
    myFriends.remove(at: indexToRemove)
}

if !myFriends.contains("윤정"){
    print("내 친구중에 윤정이 없다")
}

