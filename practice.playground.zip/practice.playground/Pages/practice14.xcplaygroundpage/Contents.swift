import UIKit
import Darwin

// final이 있으면 상속 불가
final class Friend {
    
    var name : String
    
    init(name : String){
        self.name = name
    }
}

class bestFriend : Friend{
    
    override init(name : String){
        super.init(name: "베프 " + name)
    }
}

let myFriend = Friend(name: "사람1")
let myBestFriend = Friend(name: "철수")
