import UIKit
import Foundation

// enum 경우를 나눔(케이스를 나눔)
// 학교 - 초, 중, 고
enum School {
    // case elementary
    // case middle
    // case high
    // case
    case elementary, middle, high
    
}

// var (변수) (값 변경 가능)
// let (상수) (값 변경 불가능)

let yourSchool = School.high
//print("yourSchool: \(yourSchool)")
print("yourSchool: ", yourSchool)

enum Grade : Int {
    case first = 1
    case second = 2
}
// enum의 값을 주고싶을때는 rawValue 사용
let yourGrade = Grade.first.rawValue
print("yourGrade: " , yourGrade)

enum SchoolDetail {
    case elementary(name: String)
    case middle(name: String)
    case high(name: String)
    // function - 함수 - 메서드
    // getName()을 호출하면 String 반환
    func getName() -> String {
        //SchoolDetail 나 자신이 - switch self
        switch self {
        //case 안에서 사용시 :(콜론) 사용
        case.elementary(let name):
            return name
        case let.middle(name):
            return name
        case.high(let name):
            return name
            
        }
    }
}

let yourMiddleSchoolName = SchoolDetail.middle(name :"신정중학교")

print("yourMiddleSchoolName:", yourMiddleSchoolName.getName())

// enum, 함수 연습


